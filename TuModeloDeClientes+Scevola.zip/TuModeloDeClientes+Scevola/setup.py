from setuptools import setup, find_packages

setup(
    name="paquete1",
    version="1.0",
    packages=find_packages(),
    description="Modelo de clientes",
    author="Valentín Scevola",
)
